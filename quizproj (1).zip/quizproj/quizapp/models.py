from django.db import models
from django.contrib.auth.models import User

class Subject(models.Model):
    name = models.CharField(max_length=255)
    is_answered = models.BooleanField(default=False)
    marks = models.IntegerField(default=0)

class Question(models.Model):
    subject = models.ForeignKey(Subject, on_delete=models.CASCADE, related_name='questions')
    text = models.TextField()
    created_by_superuser = models.BooleanField(default=False)

class Option(models.Model):
    question = models.ForeignKey(Question, on_delete=models.CASCADE, related_name='options')
    text = models.CharField(max_length=255)
    is_correct = models.BooleanField(default=False)


class UserMarks(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    marks = models.IntegerField(default=0)
