# forms.py
from django import forms
from .models import Question, Option
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User


# forms.py
from django import forms
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User

class RegisterForm(UserCreationForm):
    class Meta:
        model=User
        fields=['username','email','password1',
                'password2','first_name','last_name']

class LoginForm(forms.Form):
    username=forms.CharField(max_length=50)
    password=forms.CharField(max_length=50,widget=forms.PasswordInput)


