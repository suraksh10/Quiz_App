# views.py
from datetime import datetime
from django.core.mail import send_mail,EmailMessage
from reportlab.lib import colors
from .models import Subject, Question, Option,  UserMarks
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import login, logout, authenticate
from .forms import LoginForm, RegisterForm
from django.http import HttpResponse
from reportlab.pdfgen import canvas
from io import BytesIO
import datetime

def home_view(request):
    return render(request, 'quizapp/home.html')


def register_view(request):
    form = RegisterForm
    if request.method == 'POST':
        form = RegisterForm(request.POST)
        if form.is_valid():
            user = form.save(commit=False)
            user.save()
            login(request, user)
            return redirect('quiz')
        else:
            return render(request, 'quizapp/register.html', {'form': form})
    return render(request, 'quizapp/register.html', {'form': form})


# login page
def login_view(request):
    form = LoginForm
    if request.method == 'POST':
        form = LoginForm(data=request.POST)
        if form.is_valid():
            username = form.cleaned_data.get('username')
            password = form.cleaned_data.get('password')
            user = authenticate(username=username, password=password)
            if user is not None:
                login(request, user)
                return redirect('user_marks_table')
            else:
                return render(request, 'quizapp/login.html', {'form': form})
        else:
            return render(request, 'quizapp/login.html', {'form': form})
    return render(request, 'quizapp/login.html', {'form': form})




def quiz_view(request):

    Subject.objects.all().update(is_answered=False)

    subjects = Subject.objects.all()
    return render(request, 'quizapp/quiz.html', {'subjects': subjects})


def subjects_view(request):
    unanswered_subjects = Subject.objects.filter(is_answered=False)

    if unanswered_subjects.exists():
        return render(request, 'quizapp/subjects.html', {'subjects': unanswered_subjects})
    else:
        return redirect('final_submit_page')


def quiz_detail_view(request, subject_id):
    subject = get_object_or_404(Subject, pk=subject_id)

    # Check if the subject has already been answered
    if subject.is_answered:
        # Redirect to some page indicating that the subject has already been answered
        return HttpResponse("This subject has already been answered.")

    questions = Question.objects.filter(subject=subject)

    if request.method == 'POST':
        selected_options = {}
        for question in questions:
            selected_option = request.POST.get(f"question_{question.id}", None)
            selected_options[f"question_{question.id}"] = selected_option
            if not selected_option:
                # If any question is not answered, render the same page with an alert
                alert_message = "Please answer all questions before submitting."
                return render(request, 'quizapp/quiz_detail.html',
                              {'subject': subject, 'questions': questions, 'alert_message': alert_message})

        # Calculate marks
        marks = calculate_marks(questions, selected_options)

        # Save marks to the subject
        subject.marks = marks

        subject.is_answered = True
        subject.save()

        # Redirect to the subjects page
        return redirect('subjects')

        # Debugging: Print questions and options to the console
    # for question in questions:
    #     print(f"Question: {question.text}")
    #     for option in question.options.all():
    #         print(f"Option: {option.text}")

    return render(request, 'quizapp/quiz_detail.html', {'subject': subject, 'questions': questions})

def final_submit_page(request):
    subjects = Subject.objects.filter(is_answered=True)
    total_marks = sum(subject.marks for subject in subjects if hasattr(subject, 'marks'))

    # Get or create UserMarks for the current user
    user_marks, created = UserMarks.objects.get_or_create(user=request.user)

    # Update the user's marks
    user_marks.marks = total_marks
    user_marks.save()

    if total_marks > 5:
        # Send email with certificate
        send_certificate_email(request.user.email, request.user.username, total_marks)
        # Display a message on the final_submit_page
        message = "Congratulations! You earned a certificate. Check your email for details."
    else:
        # Display a message on the final_submit_page
        message = "Thank you for attending the quiz."

    return render(request, 'quizapp/final_submit_page.html', {'total_marks': user_marks.marks, 'message': message})


def calculate_marks(questions, selected_options):
    c = 0
    w = 0

    for question in questions:
        correct_option = question.options.filter(is_correct=True).first()
        selected_option_id = selected_options.get(f"question_{question.id}")

        if int(selected_option_id) == correct_option.id:
            c += 1
            print(c)
        else:
            w-=0.25
            print(w)
    marks = max(c + w, 0)
    print(f"c: {c}, w: {w}, marks: {marks}")

    return marks



def send_certificate_email(to_email, username, total_marks):
    subject = 'Certificate of Achievement'
    message = f'Dear {username},\n\nCongratulations on earning {total_marks} marks! You have successfully completed the quiz.'
    from_email = 'jeevanars2001@gmail.com'  # Set your email address
    recipient_list = [to_email]
    # Load the certificate template
    certificate_pdf = generate_certificate_pdf(username, total_marks)

    # Create an EmailMessage object
    email = EmailMessage(
        subject,
        message,
        from_email,
        recipient_list,
    )

    # Attach the certificate as a PDF file
    email.attach('certificate.pdf', certificate_pdf.getvalue(), 'application/pdf')

    # Send the email
    email.send(fail_silently=False)

    send_mail(subject, message, from_email, recipient_list, fail_silently=False)


    # Create a BytesIO buffer to save the PDF
def generate_certificate_pdf(username, total_marks):
    # Create a BytesIO buffer to save the PDF
    buffer = BytesIO()

    # Create the PDF object, using the BytesIO buffer as its "file."
    pdf = canvas.Canvas(buffer, pagesize=(8.5 * 72, 11 * 72))  # Standard letter size in points

    # Set up the PDF
    pdf.setTitle("Certificate of Achievement")

    # Set font
    pdf.setFont("Helvetica", 12)

    # Draw a decorative border with a light blue fill
    pdf.setFillColor(colors.HexColor('#AEDFF7'))  # Light Blue color
    pdf.roundRect(40, 40, 8.5 * 72 - 80, 11 * 72 - 80, radius=20, fill=True)

    # Add a header with a title
    pdf.setFont("Helvetica-Bold", 24)
    pdf.setFillColor(colors.black)
    pdf.drawCentredString(8.5 * 72 / 2, 11 * 72 - 120, "Certificate of Achievement")

    # Add user details
    pdf.setFont("Helvetica", 16)
    pdf.drawCentredString(8.5 * 72 / 2, 11 * 72 - 200, f"This is to certify that")
    pdf.drawCentredString(8.5 * 72 / 2, 11 * 72 - 230, f"{username}")
    pdf.drawCentredString(8.5 * 72 / 2, 11 * 72 - 260, f"has successfully completed the quiz and scored")
    pdf.drawCentredString(8.5 * 72 / 2, 11 * 72 - 290, f"{total_marks} Marks")

    # Add a decorative line
    pdf.setStrokeColor(colors.black)
    pdf.setLineWidth(1)
    pdf.line(8.5 * 72 / 2 - 200, 11 * 72 - 320, 8.5 * 72 / 2 + 200, 11 * 72 - 320)

    # Add a signature line
    # pdf.drawCentredString(8.5 * 72 / 2, 11 * 72 - 350, "Authorized Signature")

    # Add the date
    pdf.setFont("Helvetica-Oblique", 10)
    pdf.drawCentredString(8.5 * 72 / 2, 50, f"Issued on: {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")

    # Save the PDF content
    pdf.save()

    # File pointer reset
    buffer.seek(0)

    return buffer


def user_marks_table(request):
    # Retrieve all UserMarks objects
    all_user_marks = UserMarks.objects.all()

    return render(request, 'quizapp/user_marks_table.html', {'user_marks': all_user_marks})
