from django.urls import path
from django.contrib.auth import views as auth_views
from .views import home_view, register_view, login_view, quiz_view,  subjects_view, \
    quiz_detail_view, final_submit_page, send_certificate_email, user_marks_table

urlpatterns = [

    path('', home_view, name='home'),
    path('register/', register_view, name='register'),
    path('login/', login_view, name='login'),
    path('quiz/', quiz_view, name='quiz'),
    path('subjects/', subjects_view, name='subjects'),
    path('subjects/<int:subject_id>/', quiz_detail_view, name='quiz_detail'),
    path('final_submit_page/', final_submit_page, name='final_submit_page'),
    path('send_certificate_email/', send_certificate_email, name='certificate_template'),
    path('logout/', auth_views.LogoutView.as_view(next_page='home'), name='logout'),
    path('user_marks_table/', user_marks_table, name='user_marks_table'),


]
