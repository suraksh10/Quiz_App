# admin.py
from django.contrib import admin
from django.contrib.auth.models import User
from .models import Subject, Question, Option, UserMarks



admin.site.unregister(User)
admin.site.register(User)
admin.site.register(Subject)
admin.site.register(Question)
admin.site.register(Option)
admin.site.register(UserMarks)